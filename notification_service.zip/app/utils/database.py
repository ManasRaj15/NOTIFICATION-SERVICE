# Simulated in-memory DB
notifications_db = []