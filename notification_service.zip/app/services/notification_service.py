from app.schemas.notification import NotificationCreate
from app.queues.queue_handler import send_to_queue
from app.utils.database import notifications_db

async def send_notification(notification: NotificationCreate):
    send_to_queue(notification)
    return {"status": "queued"}

async def get_user_notifications(user_id: int):
    return [n for n in notifications_db if n["user_id"] == user_id]