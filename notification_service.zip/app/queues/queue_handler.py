import threading, time
from app.schemas.notification import NotificationCreate
from app.utils.retries import retry
from app.utils.database import notifications_db

queue = []

def send_to_queue(notification: NotificationCreate):
    queue.append(notification)
    threading.Thread(target=process_queue).start()

def process_queue():
    while queue:
        notification = queue.pop(0)
        try:
            deliver(notification)
        except Exception as e:
            print(f"Retrying due to: {e}")
            retry(lambda: deliver(notification), retries=3)

def deliver(notification):
    if notification.type == "email":
        print(f"Sending Email: {notification.message}")
    elif notification.type == "sms":
        print(f"Sending SMS: {notification.message}")
    elif notification.type == "inapp":
        print(f"Sending In-App Notification: {notification.message}")
    notifications_db.append(notification.dict())