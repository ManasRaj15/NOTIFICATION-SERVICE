from fastapi import APIRouter, HTTPException
from app.schemas.notification import NotificationCreate
from app.services.notification_service import send_notification, get_user_notifications

router = APIRouter()

@router.post("/notifications")
async def create_notification(notification: NotificationCreate):
    result = await send_notification(notification)
    return result

@router.get("/users/{user_id}/notifications")
async def read_user_notifications(user_id: int):
    return await get_user_notifications(user_id)